"# doyleRules" 

Ignore Node modules and hide node-sass script and dependency from AWS.